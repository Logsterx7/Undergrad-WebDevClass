from django.urls import path

from . import views

app_name = 'blog'
urlpatterns = [
    # ex: /2610proj/
    path('', views.index, name='index'),
    path('home', views.index, name='index'),
    path('index', views.index, name='index'),
    path('archive', views.archive, name='archive'),
    path('<int:blog_id>/', views.blogEntry, name='entry'),
    path('<int:blog_id>/comment/', views.comment, name='comment'),
    path("about",views.about,name='about'),
    path("plan",views.plan,name='plan'),
    path("techtips+css",views.techtipswithcss,name='techtips+css'),
    path("techtips-css",views.techtipswithoutcss,name='techtips-css'),
]
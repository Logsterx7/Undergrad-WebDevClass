from django.shortcuts import render,get_object_or_404
from django.utils import timezone
from django.template import loader
from .models import Comments, Blog
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

def index(request):
    latest_blog_list = Blog.objects.order_by('-posted')[:3]
    time = timezone.now()
    context = {'latest_blog_list': latest_blog_list,'time':time}
    return render(request, 'blog/index.html', context)

def archive(request):
    latest_blog_list = Blog.objects.order_by('-posted')
    commentCount = []
    content = []

    context = {'latest_blog_list': latest_blog_list}
    return render(request, 'blog/index.html', context)
def about(request):

    time = timezone.now()
    info = {"time": time}

    return render(request, 'blog/about.html',info)
def plan(request):
    time = timezone.now()
    info = {"time": time}
    return render(request, 'blog/plan.html',info)

def techtipswithcss(request):
    time = timezone.now()

    info = {"time": time}
    return render(request, 'blog/techtips+css.html',info)

def techtipswithoutcss(request):
    time = timezone.now()
    info = {"time": time}
    return render(request, 'blog/techtips-css.html',info)

def blogEntry(request,blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    com = blog.comments_set.order_by("-posted")
    context = {'blog': blog,'com':com}

    return render(request,'blog/entry.html',context)

def comment(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    com = blog.comments_set.order_by("-posted")
    name = request.POST['name']
    email = request.POST['email']
    content = request.POST['comment']
    if name =="" or email =="" or content == "":
        # Redisplay the question voting form.
        return render(request, 'blog/entry.html', {
            'blog': blog,
            'error_message': "You didn't fill out all of the information!",
            'com': com
        })
    else:
        c = Comments(blog=blog,commenter=name,email=email,content=content,posted=timezone.now())
        c.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('blog:entry', args=(blog.id,)))
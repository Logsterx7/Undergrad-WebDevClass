function main(){
    //changes title
    document.title = "JavaScript Calculator!";
    //creates elements
    let div = document.createElement('div');
    let resDiv = document.createElement('div');
    let h1 = document.createElement('h1');

    //create variables and set their values up to grab input
    var num1 = numInput(0);
    var num2 = numInput(1);
    var color = colorInput();
    var button = buttonInput();


    //append things to their parent nodes and add information
    div.appendChild(h1);
    h1.textContent = "JavaScript Calculator";
    let h3 = document.createElement('h3');
    h3.textContent = "Please create an expression below:";
    div.appendChild(h3);
    div.setAttribute('class',"stuff-box");
    document.body.appendChild(div);
    let op = operators();
    let p = document.createElement("p");

    div.appendChild(p);
    p.appendChild(num1);
    p.appendChild(op);
    p.appendChild(num2);
    p.appendChild(button);
    div.appendChild(color);
    document.body.appendChild(resDiv)

    //creates button to calculate
    function buttonInput(){
        let button = document.createElement("input");
        button.type = "button";
        button.value = "Compute"
        button.addEventListener('click', compute);
        return button;

    }

    function compute(){
        let resultDiv = document.createElement("div");
        var res;
        //looks for what operator was selected
        try{
        if(op.value == "+"){
        res = eval(num1.value +"+"+ num2.value)
        }
        else if(op.value == "-"){
        res = eval(num1.value +"-"+ num2.value)
        }
        else if(op.value == "/"){
        res = eval(num1.value +"/"+ num2.value)
        }
        else if(op.value == "*"){
        res = eval(num1.value +"*"+ num2.value)
        }
        else if(op.value == "%"){
        res = eval(num1.value +"%"+ num2.value)
        }
        else if(op.value == "**"){
        res = eval(num1.value +"**"+ num2.value)
        }
        //catches errors if one or more number is missing
        }catch (error) {
            res = "Error!"
        }
        //style the smaller divs
        resultDiv.setAttribute('class',"stuff-box");
        //words inside the div
        var resPar = document.createElement("p");
        var time = new Date().toString()
        if(res == "Error!"){
        resPar.textContent = time + "  "+res;
        resultDiv.style.backgroundColor = "red";
        }
        else{resPar.textContent = time + "  " + num1.value +" "+op.value+" "+num2.value+" = "+res;
            resultDiv.style.backgroundColor = color.value;
        }
        //appends last results
        resultDiv.appendChild(resPar);

        //delete event
        resultDiv.addEventListener("click", function(event){
        resultDiv.remove();
        })
        resDiv.insertBefore(resultDiv,resDiv.firstElementChild);
    }


}
    function operators(){
    //creates and returns drop-down menu for operators
        let op = document.createElement("select");
        let plus = document.createElement("option");
        plus.textContent = "+";
        op.appendChild(plus);

        let sub = document.createElement("option");
        sub.textContent = "-";
        op.appendChild(sub);

        let div = document.createElement("option");
        div.textContent = "/";
        op.appendChild(div);

        let mult = document.createElement("option");
        mult.textContent = "*";
        op.appendChild(mult);

        let mod = document.createElement("option");
        mod.textContent = "%";
        op.appendChild(mod);

        let pow = document.createElement("option");
        pow.textContent = "**";
        op.appendChild(pow);
        return op

    }
    //snags number inputs
    function numInput(numId){
        let numin = document.createElement("input");
        numin.type = "number";
        numin.id = numId;
        return numin;

    }
    //snags the color input
    function colorInput(){
        let colorIn = document.createElement("input");
        colorIn.type = "color";
        return colorIn;

    }

//classic main call
main();
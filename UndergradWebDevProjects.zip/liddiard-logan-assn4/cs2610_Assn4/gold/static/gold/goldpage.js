function main(){
    //changes title
    document.title = "Whats your weight in gold?";
    price = null;
    var time = new Date().toString()
    //creates elements
    let div = document.createElement('div');
    let resDiv = document.createElement('div');
    let h1 = document.createElement('h1');
    let currentVal = document.createElement("p")

    //makes fetch request for current gold price.
    currentVal.textContent = "Please wait..."
    fetch('https://data.nasdaq.com/api/v3/datasets/LBMA/GOLD?limit=1&api_key=zBqutvdUtxkKHJ4PfNVV', {
            headers: { Accept: 'application/json'}
        })
        .then(r => r.json())
        .then(r => {console.log(r.dataset.data[0][2])
            price = r.dataset.data[0][2]
            currentVal.textContent = "Here is the current value of gold per Troy Ounce as of "+time+" : "+r.dataset.data[0][2];
            })
        .catch( err => {
        currentVal.textContent = "Something went wrong. Please try again."
        })

    //create variables and set their values up to grab input
    var weight = numInput(0);
    var button = buttonInput();

    //creates elements and sets styles
    div.appendChild(h1);
    h1.textContent = "What's your weight in gold?";
    let h3 = document.createElement('h3');
    h3.textContent = "Input your weight and press the = Button to see what you're worth!";
    div.appendChild(h3);
    div.setAttribute('class',"stuff-box");
    document.body.appendChild(div);
    let unit = operators();
    let p = document.createElement("p");

    //appends rest of divs and elements
    div.appendChild(p);
    p.appendChild(weight);
    p.appendChild(unit);
    p.appendChild(button);
    div.appendChild(currentVal)
    document.body.appendChild(resDiv)

    //creates button to calculate weight in gold.
    function buttonInput(){
        let button = document.createElement("input");
        button.type = "button";
        button.value = "="
        button.addEventListener('click', compute);
        return button;
    }

//grabs info needed through unitconv API and error handles inputs
    function compute(){
    //creates div and sets style
        let resultDiv = document.createElement("div");
        resultDiv.setAttribute('class',"stuff-box");
        var resPar = document.createElement("p");

        //Won't let fetch go through if inputs are invalid
        if(weight.value==""){
            resPar.textContent = "Error! Input field left blank.";
            resultDiv.style.backgroundColor = "red";
        }
        else if(weight.value < 0){
            resPar.textContent = "Error! Input field cannot be a negative number.";
            resultDiv.style.backgroundColor = "red";
        }
        else if(isNaN(weight.value)){
            resPar.textContent = "Error! Input field must be a number.";
            resultDiv.style.backgroundColor = "red";
        }

        //input is valid and can be processed
        else{
        resPar.textContent = "Fetching results...";
        fetch('http://localhost:8000/unitconv/convert?from='+convertOperators(unit.value)+'&to=t_oz&value='+weight.value, {
            headers: { Accept: 'application/json'}
        })
        .then(r => r.json())
        .then(r => {
            resPar.textContent = time+" Your weight is in gold $"+(r.value*price).toFixed(2)+ " in "+unit.value+"!";
            resultDiv.style.backgroundColor = "gold";
            })
            //if something goes wrong with request, feedback on this is given
        .catch( err => {
        resPar.textContent = "Something went wrong. Please try again. " + err
        })

        }

        //appends last results
        resultDiv.appendChild(resPar);

        //delete event
        resultDiv.addEventListener("click", function(event){
        resultDiv.remove();
        })
        //creates reverse ordering so newest is first
        resDiv.insertBefore(resultDiv,resDiv.firstElementChild);

    }
}

//converts inputs from their string form so that they can take a form to use in request to unitconv API
    function convertOperators(input){

    if(input == "Tons"){
        return "T"
        }
        else if(input == "Grams"){
        return "g"
        }
        else if(input == "Troy Ounces"){
        return "t_oz"
        }
        else if(input == "Kilograms"){
        return "kg"
        }
        else if(input == "Imperial Pound"){
        return "lb"
        }
        else if(input == "Ounces"){
        return "oz"
        }

    }


    function operators(){
    //creates and returns drop-down menu for operators
        let unit = document.createElement("select");
        let t = document.createElement("option");
        t.textContent = "Tons";
        unit.appendChild(t);

        let g = document.createElement("option");
        g.textContent = "Grams";
        unit.appendChild(g);

        let t_oz = document.createElement("option");
        t_oz.textContent = "Troy Ounces";
        unit.appendChild(t_oz);

        let kg = document.createElement("option");
        kg.textContent = "Kilograms";
        unit.appendChild(kg);

        let lb = document.createElement("option");
        lb.textContent = "Imperial Pound";
        unit.appendChild(lb);

        let oz = document.createElement("option");
        oz.textContent = "Ounces";
        unit.appendChild(oz);
        return unit

    }
    //creates number inputs
    function numInput(numId){
        let numin = document.createElement("input");
        numin.type = "number";
        numin.id = numId;
        return numin;

    }

//main call to build up webpage
main();
from django.urls import path

from . import views

app_name = 'gold'
urlpatterns = [
    # ex: /2610proj/
    path('', views.index, name='index'),
    path('gold', views.index, name='index'),

]
from django.db import models

class Unit(models.Model):
    type = models.CharField(max_length=20)
    value = models.FloatField()


    def __str__(self):
        return self.type

# Create your models here.

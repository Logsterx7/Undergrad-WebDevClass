from django.urls import path

from . import views

app_name = 'unitconv'
urlpatterns = [

    # ex: /2610proj/
    path('', views.index, name='index'),
    path('convert',views.convert,name='convert'),
    path('unitconv', views.convert, name='convert'),

]
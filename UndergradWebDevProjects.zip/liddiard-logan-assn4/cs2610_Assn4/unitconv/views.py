from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from .models import Unit
from django.shortcuts import render

def convert(request):
    fromVal = request.GET.get('from')
    to = request.GET.get('to')
    value = request.GET.get('value')
    units = Unit.objects.all()
    fromToz = None
    toToz = None
    ans = None
    ##finds if from and to are available
    for unit in units:
        if unit.type == fromVal: fromToz = unit
        if unit.type == to: toToz = unit
    ##catches error if type is not supported
    if fromToz == None or toToz == None:
        context = {"error": "Error! Atleast one conversion type is not found."}
        return JsonResponse(context)
    ##catches error if value is not a float/int

    try:
        if value == None:
            context = {"error": "Error! Missing value."}
            return JsonResponse(context)
        floatValue = float(value)
        if floatValue<0:
            context = {"error": "Error! Value MUST be a positive number."}
            return JsonResponse(context)

    except:
        context = {"error": "Error! Value MUST be an integer or a float."}
        return JsonResponse(context)

    ##builds and returns JSON obj
    ans = (fromToz.value * floatValue) / (toToz.value)

    ##CORS has to ruin all my fun, so heres this block added to prevent that CORS error
    context = {"units" : to, "value": ans}
    response = JsonResponse(context)
    response['Access-Control-Allow-Origin'] = '*'
    return response
    return JsonResponse(context)

def index(request):
    response = "You're looking at the results of question %s."
    return HttpResponse("<h1>Welcome to the unitconv page!</h1>"
                        "<h2>Each of the following information myst be included in the request:</h2>"
                        "<ol>"
                        "<li>from = T | g | t_oz | kg |lb | oz</li>"
                        "<li>to = T | g | t_oz | kg |lb | oz</li>"
                        "<li>value = a floating point number</li>"
                        "</ol>")

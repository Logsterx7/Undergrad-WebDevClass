Dear grader, At the time of me submitting this assignment. The API key I have left behind has exactly **49 calls left.** 
So if you decide or are required to use my API key rather
than your own or one provided by Erik, There are plenty of calls left available.


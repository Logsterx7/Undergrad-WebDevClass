

const app = Vue.createApp({
        data() {
            return {
            //API KEYS
            apikeyGEO: "GVSEI5hoQZqSVGKNleaoYX2VkdBWVtkWUhOIGXAJ",
            apikeyWEATHER: "b8869b0899e42c451643cc9572dd6457",
            //default variables
            likely: 0,
            unlikely: 0,
            neutral: 40,
            fetchingLoc: true,
            fetchingCon: true,
            fetchingDays: true,
            time: null,
            error: false,
            long: null,
            lati: null,
            city: null,
            state: null,
            country: null,
            currentTemp: null,
            currentHigh: null,
            currentLow: null,
            currentSky: null,
            currentHumidity: null,
            currentPressure: null,
            weatherJson : null,
            states: [ 'neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral',
                      'neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral',
                      'neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral',
                      'neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral', 'neutral', 'neutral','neutral', 'neutral'],



            };
        },

methods: {
    //keeps count of the states and updates them
    countStates(){

    tempNeut = 0;
    tempLike = 0;
    tempNotLike = 0;

    for (let i = 0; i < this.states.length; i++) {
    if(this.states[i]=="likely"){ tempLike += 1}
    else if(this.states[i]=="neutral"){ tempNeut += 1}
    else if(this.states[i]=="unlikely"){ tempNotLike += 1}

}
    vm.likely=tempLike;
    vm.unlikely=tempNotLike;
    vm.neutral=tempNeut;


    },
    //code slightly modified by Eriks.
    forecastToggle(event) {

        // Get the index of this <div> from the DOM
        let div = event.currentTarget;
        let idx = div.getAttribute('data-index');

        if (this.states[idx] === 'neutral') {
            this.states[idx] = 'likely';
        }
        else if (this.states[idx] === 'likely') {
            this.states[idx] = 'unlikely';
        }
        else if (this.states[idx] === 'unlikely') {
            this.states[idx] = 'neutral';
        }

        div.setAttribute('class', this.states[idx]);
        vm.countStates();
        }
    },
    //makes chain promise objects upon calling
    created(){
    fetch("https://api.ipbase.com/v2/info?apikey="+this.apikeyGEO)
    .then(r => r.json())
    .then(json => {
    //by turning this false. it switches from letting user know it is currently being fetched to displaying new information
        vm.fetchingLoc = false;
        vm.time= json.data.timezone.current_time;
        vm.lati = json.data.location.latitude;
        vm.long = json.data.location.longitude;
        vm.city = json.data.location.city.name;
        vm.state = json.data.location.region.name;
        vm.country = json.data.location.country.name;

        //next promise call
        return fetch("https://api.openweathermap.org/data/2.5/weather?lat="+vm.lati+"&lon="+vm.long+"&units=imperial&appid="+this.apikeyWEATHER);
    })
    .then(r => r.json())
    .then(json => {
    //by turning this false. it switches from letting user know it is currently being fetched to displaying new information
        vm.fetchingCon = false;
        vm.currentTemp = json.main.temp;
        vm.currentHigh = json.main.temp_max;
        vm.currentLow = json.main.temp_min;
        vm.currentSky = json.weather[0].description;
        vm.currentHumidity = json.main.humidity;
        vm.currentPressure = json.main.pressure;

        return fetch("https://api.openweathermap.org/data/2.5/forecast?lat="+vm.lati+"&lon="+vm.long+"&appid="+vm.apikeyWEATHER+"&units=imperial");
    })
    .then(r => r.json())
    .then(json => {
    //by turning this false. it switches from letting user know it is currently being fetched to displaying new information
    vm.fetchingDays = false;
    vm.weatherJson = json.list;

}
    )
    .catch(err => {
    vm.error = true;
    });

    }
});

const vm = app.mount('#app');







